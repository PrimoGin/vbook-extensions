load("voice_list.js");

// Các model thử lần lượt nếu model trước không tồn tại (tên model Google hay đổi)
const MODELS = [
    "gemini-3.1-flash-tts-preview",
    "gemini-2.5-flash-preview-tts"
];
const SAMPLE_RATE = 24000; // Gemini TTS trả PCM 16-bit mono 24kHz

let apiKeys = [];
let keyIndex = -1;
try {
    apiKeys = (api_keys || "").split("\n").map(function (k) {
        return k.trim();
    }).filter(function (k) {
        return k !== "";
    });
} catch (e) {}

function execute(text, voice) {
    if (apiKeys.length === 0) return null;
    let voiceInfo = voices.find(function (e) {
        return e.id == voice;
    });
    let voiceName = voiceInfo ? voiceInfo.id : "Kore";

    for (let m = 0; m < MODELS.length; m++) {
        let triedKeys = 0;
        let maxTries = apiKeys.length * 2;
        while (triedKeys < maxTries) {
            triedKeys++;
            let apiKey = nextKey();
            let response;
            try {
                response = fetch("https://generativelanguage.googleapis.com/v1beta/models/" + MODELS[m] + ":generateContent", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "x-goog-api-key": apiKey
                    },
                    body: JSON.stringify({
                        contents: [{parts: [{text: text}]}],
                        generationConfig: {
                            responseModalities: ["AUDIO"],
                            speechConfig: {
                                voiceConfig: {prebuiltVoiceConfig: {voiceName: voiceName}}
                            }
                        }
                    })
                });
            } catch (err) {
                return null;
            }

            if (response.ok) {
                let json = response.json();
                let pcm = findAudio(json);
                if (pcm) return Response.success(pcmBase64ToWavBase64(pcm));
                return null;
            }
            if (response.status === 404) break;           // model không tồn tại -> thử model kế
            if (response.status === 429) {                // hết quota -> đổi key, chờ chút
                sleep(1500);
                continue;
            }
            if (response.status === 400 || response.status === 403) {
                // key sai/bị chặn hoặc model không hỗ trợ -> bỏ key này nếu còn key khác
                if (apiKeys.length > 1) {
                    apiKeys = apiKeys.filter(function (k) {
                        return k !== apiKey;
                    });
                    keyIndex = -1;
                    continue;
                }
                break;
            }
            sleep(500);
        }
    }
    return null;
}

function nextKey() {
    keyIndex = (keyIndex + 1) % apiKeys.length;
    return apiKeys[keyIndex];
}

function findAudio(json) {
    try {
        let parts = json.candidates[0].content.parts;
        for (let i = 0; i < parts.length; i++) {
            let d = parts[i].inlineData || parts[i].inline_data;
            if (d && d.data) return d.data;
        }
    } catch (e) {}
    return null;
}

// ---- Ghép header WAV mà không phải giải mã PCM ----
// Header 54 byte (có chunk JUNK 2 byte để chia hết cho 3) nên base64(header) + base64(pcm) là hợp lệ.
const B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

function bytesToBase64(bytes) {
    let out = "";
    for (let i = 0; i < bytes.length; i += 3) {
        let n = (bytes[i] << 16) | (bytes[i + 1] << 8) | bytes[i + 2];
        out += B64.charAt((n >> 18) & 63) + B64.charAt((n >> 12) & 63) + B64.charAt((n >> 6) & 63) + B64.charAt(n & 63);
    }
    return out;
}

function pcmBase64ToWavBase64(pcmB64) {
    pcmB64 = pcmB64.replace(/[\r\n\s]/g, "");
    let pad = 0;
    if (pcmB64.charAt(pcmB64.length - 1) === "=") pad++;
    if (pcmB64.charAt(pcmB64.length - 2) === "=") pad++;
    let dataLen = (pcmB64.length / 4) * 3 - pad;

    let h = [];
    function str(s) {
        for (let i = 0; i < s.length; i++) h.push(s.charCodeAt(i));
    }
    function u32(v) {
        h.push(v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >> 24) & 255);
    }
    function u16(v) {
        h.push(v & 255, (v >> 8) & 255);
    }
    str("RIFF"); u32(46 + dataLen); str("WAVE");
    str("fmt "); u32(16); u16(1); u16(1); u32(SAMPLE_RATE); u32(SAMPLE_RATE * 2); u16(2); u16(16);
    str("JUNK"); u32(2); u16(0);
    str("data"); u32(dataLen);
    return bytesToBase64(h) + pcmB64;
}
