load("voice_list.js");

// Flash/Turbo v2.5 hỗ trợ tiếng Việt (Multilingual v2 thì không). Lượt cuối thử lại không gửi language_code.
const ATTEMPTS = [
    {model: "eleven_flash_v2_5", lang: true},
    {model: "eleven_turbo_v2_5", lang: true},
    {model: "eleven_flash_v2_5", lang: false}
];

let apiKeys = [];
let keyIndex = -1;
try {
    apiKeys = (api_keys || "").split("\n").map(function (k) {
        return k.trim();
    }).filter(function (k) {
        return k !== "";
    });
} catch (e) {}

function execute(text, voice) {
    if (apiKeys.length === 0) return null;
    let voiceId = voice || voices[0].id;

    for (let m = 0; m < ATTEMPTS.length; m++) {
        let tries = 0;
        let maxTries = apiKeys.length * 2 + 2;
        while (tries < maxTries && apiKeys.length > 0) {
            tries++;
            let apiKey = nextKey();
            let payload = {text: text, model_id: ATTEMPTS[m].model};
            if (ATTEMPTS[m].lang) payload.language_code = "vi";
            let response;
            try {
                response = fetch("https://api.elevenlabs.io/v1/text-to-speech/" + voiceId + "?output_format=mp3_44100_128", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "xi-api-key": apiKey
                    },
                    body: JSON.stringify(payload)
                });
            } catch (err) {
                return null;
            }

            if (response.ok) {
                return Response.success(response.base64());
            }
            if (response.status === 429) {      // vượt số request đồng thời -> chờ rồi thử lại
                sleep(1500);
                continue;
            }
            if (response.status === 401) {      // key sai hoặc hết hạn mức -> bỏ key này, thử key khác
                apiKeys = apiKeys.filter(function (k) {
                    return k !== apiKey;
                });
                keyIndex = -1;
                continue;
            }
            if (response.status === 400 || response.status === 404 || response.status === 422) {
                break;                          // model/tham số không hợp lệ -> thử cấu hình kế tiếp
            }
            sleep(500);
        }
    }
    return null;
}

function nextKey() {
    keyIndex = (keyIndex + 1) % apiKeys.length;
    return apiKeys[keyIndex];
}
