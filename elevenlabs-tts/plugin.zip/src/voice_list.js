// Danh sách dự phòng (giọng dựng sẵn của ElevenLabs). Nếu có API key, voice.js sẽ lấy danh sách thật từ tài khoản.
let voices = [
    {id: "JBFqnCBsd6RMkjVDRZzb", language: "vi-VN", name: "George"},
    {id: "21m00Tcm4TlvDq8ikWAM", language: "vi-VN", name: "Rachel"},
    {id: "pNInz6obpgDQGcFmaJgB", language: "vi-VN", name: "Adam"},
    {id: "EXAVITQu4vr4xnSDxMaL", language: "vi-VN", name: "Sarah"},
    {id: "nPczCjzI2devNBz1zQrb", language: "vi-VN", name: "Brian"},
    {id: "onwK4e9ZLuTAKqWW03F9", language: "vi-VN", name: "Daniel"}
]
