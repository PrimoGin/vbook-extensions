load("voice_list.js");

function execute() {
    try {
        let keys = (api_keys || "").split("\n").map(function (k) {
            return k.trim();
        }).filter(function (k) {
            return k !== "";
        });
        if (keys.length > 0) {
            let r = fetch("https://api.elevenlabs.io/v1/voices", {
                headers: {"xi-api-key": keys[0]}
            });
            if (r.ok) {
                let j = r.json();
                if (j && j.voices && j.voices.length > 0) {
                    let list = j.voices.slice(0, 50).map(function (v) {
                        return {id: v.voice_id, language: "vi-VN", name: v.name};
                    });
                    return Response.success(list);
                }
            }
        }
    } catch (e) {}
    return Response.success(voices);
}
