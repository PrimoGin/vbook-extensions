load("voice_list.js");

function execute() {
    let reason = "";
    try {
        if (typeof api_keys === "undefined") {
            reason = "voice.js không đọc được ô API key";
        } else {
            let lines = (api_keys || "").split("\n").map(function (k) {
                return k.trim();
            }).filter(function (k) {
                return k !== "";
            });
            if (lines.length === 0) {
                reason = "chưa nhập API key";
            } else {
                let key = lines[0].split("|")[0].trim();
                let list = [];
                let cursor = "";
                for (let page = 0; page < 5; page++) {
                    let url = "https://larvoice.com/api/v1/voices?voice_type=public&language=vi&limit=100" +
                        (cursor !== "" ? "&cursor=" + cursor : "");
                    let r = fetch(url, {headers: {"Authorization": "Bearer " + key}});
                    if (!r.ok) {
                        reason = "HTTP " + r.status;
                        break;
                    }
                    let j = r.json();
                    let d = j && j.data ? j.data : j;
                    let arr = d && d.voices ? d.voices : [];
                    for (let i = 0; i < arr.length; i++) {
                        let v = arr[i];
                        let id = String(v.voice_id || v.id);
                        let g = v.gender === "male" ? " (nam)" : (v.gender === "female" ? " (nữ)" : "");
                        list.push({id: id, language: "vi-VN", name: v.name + g + " #" + id});
                    }
                    if (d && d.has_more && d.next_cursor) cursor = d.next_cursor; else break;
                }
                if (reason === "" && list.length > 0) return Response.success(list);
                if (reason === "") reason = "danh sách rỗng";
            }
        }
    } catch (e) {
        reason = "lỗi " + e;
    }
    return Response.success(voices.map(function (v) {
        return {id: v.id, language: v.language, name: v.name + " [" + reason + "]"};
    }));
}
