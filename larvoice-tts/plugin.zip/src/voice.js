load("voice_list.js");

function execute() {
    let reason = "";
    try {
        let list = [];
        for (let page = 1; page <= 6; page++) {
            let r = fetch("https://api.larvoice.com/voices?language=vi&per_page=30&page=" + page);
            if (!r.ok) {
                reason = "HTTP " + r.status;
                break;
            }
            let j = r.json();
            let arr = j && j.data ? j.data : [];
            for (let i = 0; i < arr.length; i++) {
                let v = arr[i];
                let id = v.voice_id || v.id;
                if (!id) continue;
                let g = v.sex === "male" ? " (nam)" : (v.sex === "female" ? " (nữ)" : "");
                list.push({id: String(id), language: "vi-VN", name: (v.voice_name || v.name || id) + g});
            }
            if (arr.length < 30) break;
        }
        if (list.length > 0) return Response.success(list);
        if (reason === "") reason = "danh sách rỗng";
    } catch (e) {
        reason = "lỗi " + e;
    }
    return Response.success(voices.map(function (v) {
        return {id: v.id, language: v.language, name: v.name + " [" + reason + "]"};
    }));
}
