load("voice_list.js");

function execute() {
    let reason = "";
    try {
        if (typeof api_keys === "undefined") {
            reason = "voice.js không đọc được ô API key";
        } else {
            let lines = (api_keys || "").split("\n").map(function (k) {
                return k.trim();
            }).filter(function (k) {
                return k !== "";
            });
            if (lines.length === 0) {
                reason = "chưa nhập API key";
            } else {
                let key = lines[0].split("|")[0].trim();
                let r = fetch("https://larvoice.com/api/voice", {headers: {"apikey": key}});
                if (!r.ok) {
                    reason = "HTTP " + r.status;
                } else {
                    let j = r.json();
                    let arr = j && j.data ? j.data : (Array.isArray(j) ? j : []);
                    let list = [];
                    for (let i = 0; i < arr.length; i++) {
                        let v = arr[i];
                        if (v.status && v.status !== "active") continue;
                        let g = v.gender === "male" ? " (nam)" : (v.gender === "female" ? " (nữ)" : "");
                        list.push({id: String(v.id), language: "vi-VN", name: v.name + g});
                    }
                    if (list.length > 0) return Response.success(list);
                    reason = "danh sách rỗng";
                }
            }
        }
    } catch (e) {
        reason = "lỗi " + e;
    }
    // Không lấy được danh sách thật: trả về giọng dự phòng, kèm lý do trong tên để dễ chẩn đoán
    return Response.success(voices.map(function (v) {
        return {id: v.id, language: v.language, name: v.name + " [" + reason + "]"};
    }));
}
