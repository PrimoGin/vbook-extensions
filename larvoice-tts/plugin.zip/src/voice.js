load("voice_list.js");

function execute() {
    try {
        let lines = (api_keys || "").split("\n").map(function (k) {
            return k.trim();
        }).filter(function (k) {
            return k !== "";
        });
        if (lines.length > 0) {
            let key = lines[0].split("|")[0].trim();
            let r = fetch("https://larvoice.com/api/voice", {headers: {"apikey": key}});
            if (r.ok) {
                let j = r.json();
                let arr = j && j.data ? j.data : (Array.isArray(j) ? j : []);
                let list = [];
                for (let i = 0; i < arr.length; i++) {
                    let v = arr[i];
                    if (v.status && v.status !== "active") continue;
                    let g = v.gender === "male" ? " (nam)" : (v.gender === "female" ? " (nữ)" : "");
                    list.push({id: String(v.id), language: "vi-VN", name: v.name + g});
                }
                if (list.length > 0) return Response.success(list);
            }
        }
    } catch (e) {}
    return Response.success(voices);
}
