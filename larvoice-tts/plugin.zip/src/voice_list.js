// Danh sách dự phòng (ID lấy từ ví dụ trong tài liệu LarVoice). Có API key thì voice.js lấy danh sách thật.
let voices = [
    {id: "836", language: "vi-VN", name: "Giọng 836"},
    {id: "927", language: "vi-VN", name: "Kỳ Anh"}
]
