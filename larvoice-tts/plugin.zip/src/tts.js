load("voice_list.js");

const BASE = "https://api.larvoice.com";

// Mỗi dòng: KEY hoặc KEY|VOICE_ID (VOICE_ID ghi đè giọng chọn trong vBook)
let entries = [];
let entryIndex = -1;
try {
    entries = (api_keys || "").split("\n").map(function (l) {
        return l.trim();
    }).filter(function (l) {
        return l !== "";
    }).map(function (l) {
        let p = l.split("|");
        let v = p.length >= 3 ? p[2] : (p.length === 2 ? p[1] : "");
        return {key: p[0].trim(), voice: (v || "").trim()};
    });
} catch (e) {}

function execute(text, voice) {
    if (entries.length === 0) return null;
    let voiceId = voice || voices[0].id;
    let tries = 0;
    let maxTries = entries.length * 2 + 1;

    while (tries < maxTries && entries.length > 0) {
        tries++;
        let entry = nextEntry();
        let res = createSpeech(entry, text, entry.voice || voiceId);

        if (res.error === "auth" || res.error === "credits") {
            entries = entries.filter(function (e) {
                return e !== entry;
            });
            entryIndex = -1;
            continue;
        }
        if (res.error === "limit") {
            sleep(res.wait || 2000);
            continue;
        }
        if (res.error || !res.url) return null;

        let r = fetch(res.url);
        if (!r.ok) r = fetch(res.url, {headers: {"Authorization": "Bearer " + entry.key}});
        if (!r.ok) return null;
        return Response.success(r.base64());
    }
    return null;
}

function nextEntry() {
    entryIndex = (entryIndex + 1) % entries.length;
    return entries[entryIndex];
}

function createSpeech(entry, text, voiceId) {
    let body = JSON.stringify({
        model: "v3-fast",
        language: "vi",
        text: text,
        voice_id: String(voiceId)
    });
    let r;
    try {
        r = fetch(BASE + "/v1/tts", {
            method: "POST",
            headers: {"Authorization": "Bearer " + entry.key, "Content-Type": "application/json"},
            body: body
        });
    } catch (err) {
        return {error: "network"};
    }
    if (r.status === 401 || r.status === 403) return {error: "auth"};
    if (r.status === 402) return {error: "credits"};
    if (r.status === 429) return {error: "limit", wait: 3000};
    if (!r.ok) return {error: "other"};
    let j;
    try {
        j = r.json();
    } catch (e) {
        return {error: "other"};
    }
    if (j && j.success === false) return {error: "other"};
    if (j && j.audio_url) return {url: j.audio_url};
    return {error: "other"};
}
