load("voice_list.js");

const BASE = "https://larvoice.com";

// Mỗi dòng: KEY hoặc KEY|VOICE_ID  (VOICE_ID ghi đè giọng chọn trong vBook)
let entries = [];
let entryIndex = -1;
try {
    entries = (api_keys || "").split("\n").map(function (l) {
        return l.trim();
    }).filter(function (l) {
        return l !== "";
    }).map(function (l) {
        let p = l.split("|");
        // tương thích kiểu cũ KEY|MODEL|VOICE: lấy trường cuối nếu có >= 3 trường
        let v = p.length >= 3 ? p[2] : (p.length === 2 ? p[1] : "");
        return {key: p[0].trim(), voice: (v || "").trim()};
    });
} catch (e) {}

function execute(text, voice) {
    if (entries.length === 0) return null;
    let voiceId = voice || voices[0].id;
    let tries = 0;
    let maxTries = entries.length * 2 + 1;

    while (tries < maxTries && entries.length > 0) {
        tries++;
        let entry = nextEntry();
        let res = createJob(entry, text, entry.voice || voiceId);

        if (res.error === "auth" || res.error === "credits") {
            entries = entries.filter(function (e) {
                return e !== entry;
            });
            entryIndex = -1;
            continue;
        }
        if (res.error === "limit") {
            sleep(2000);
            continue;
        }
        if (res.error) return null;

        let url = res.url;
        if (!url && res.jobUrl) url = waitJob(res.jobUrl, entry.key);
        if (!url) return null;
        let b64 = downloadAudio(url, entry.key);
        if (!b64) return null;
        return Response.success(b64);
    }
    return null;
}

function nextEntry() {
    entryIndex = (entryIndex + 1) % entries.length;
    return entries[entryIndex];
}

function authHeaders(key) {
    return {"Authorization": "Bearer " + key, "Content-Type": "application/json"};
}

function createJob(entry, text, voiceId) {
    let formats = ["mp3", "wav"];
    for (let f = 0; f < formats.length; f++) {
        let body = JSON.stringify({
            voice_id: String(voiceId),
            voice_type: "public",
            gen_text: text,
            language: "vi",
            format: formats[f],
            return_srt: false
        });
        let r;
        try {
            r = fetch(BASE + "/api/v1/tts", {method: "POST", headers: authHeaders(entry.key), body: body});
        } catch (err) {
            return {error: "network"};
        }
        if (r.status === 401 || r.status === 403) return {error: "auth"};
        if (r.status === 402) return {error: "credits"};
        if (r.status === 429) return {error: "limit"};
        if (r.ok) {
            let d = unwrap(safeJson(r));
            if (!d) continue;
            let job = d.job || d;
            let url = d.output_url || job.output_url || d.download_url || job.download_url;
            let st = String(job.status || d.status || "").toLowerCase();
            if (url && (st === "" || st === "completed")) return {url: url};
            let jobUrl = d.job_url || job.job_url;
            if (!jobUrl && (d.job_id || job.id)) jobUrl = BASE + "/api/v1/jobs/" + (d.job_id || job.id);
            if (jobUrl) return {jobUrl: jobUrl};
        }
    }
    return {error: "other"};
}

function waitJob(jobUrl, key) {
    if (jobUrl.indexOf("http") !== 0) jobUrl = BASE + jobUrl;
    for (let i = 0; i < 90; i++) {
        let r;
        try {
            r = fetch(jobUrl, {headers: authHeaders(key)});
        } catch (err) {
            return null;
        }
        if (r.ok) {
            let d = unwrap(safeJson(r));
            let job = d && d.job ? d.job : d;
            if (job) {
                let st = String(job.status || "").toLowerCase();
                if (st === "failed") return null;
                if (st === "completed" && job.output_url) return job.output_url;
            }
        } else if (r.status === 401 || r.status === 403 || r.status === 404) {
            return null;
        }
        sleep(1000);
    }
    return null;
}

function downloadAudio(url, key) {
    if (url.indexOf("http") !== 0) url = BASE + (url.charAt(0) === "/" ? "" : "/") + url;
    let r = fetch(url);
    if (!r.ok) r = fetch(url, {headers: {"Authorization": "Bearer " + key}});
    return r.ok ? r.base64() : null;
}

function safeJson(r) {
    try {
        return r.json();
    } catch (e) {
        return null;
    }
}

function unwrap(j) {
    if (j && j.data && typeof j.data === "object" && !Array.isArray(j.data)) return j.data;
    return j;
}
