load("voice_list.js");

const BASE = "https://larvoice.com";

let entries = [];
let entryIndex = -1;
try {
    entries = (api_keys || "").split("\n").map(function (l) {
        return l.trim();
    }).filter(function (l) {
        return l !== "";
    }).map(function (l) {
        let p = l.split("|");
        let model = (p.length > 1 && p[1].trim() !== "") ? p[1].trim() : "1";
        return {key: p[0].trim(), model: model};
    });
} catch (e) {}

function execute(text, voice) {
    if (entries.length === 0) return null;
    let voiceId = voice || voices[0].id;
    let tries = 0;
    let maxTries = entries.length * 2 + 1;

    while (tries < maxTries && entries.length > 0) {
        tries++;
        let entry = nextEntry();
        let job = createJob(entry, text, voiceId);

        if (job.error === "auth") {            // key sai/hết hạn -> bỏ key này
            entries = entries.filter(function (e) {
                return e !== entry;
            });
            entryIndex = -1;
            continue;
        }
        if (job.error === "limit") {           // bị giới hạn -> chờ rồi thử lại
            sleep(2000);
            continue;
        }
        if (!job.id) return null;

        let path = waitResult(job.id, entry.key);
        if (!path) return null;
        let b64 = downloadAudio(path, entry.key);
        if (!b64) return null;
        return Response.success(b64);
    }
    return null;
}

function nextEntry() {
    entryIndex = (entryIndex + 1) % entries.length;
    return entries[entryIndex];
}

// Thử lần lượt: mp3/wav x multipart/urlencoded (tài liệu chỉ ghi multipart + wav)
function createJob(entry, text, voiceId) {
    let formats = ["mp3", "wav"];
    let encodings = ["multipart", "urlencoded"];
    for (let f = 0; f < formats.length; f++) {
        for (let e = 0; e < encodings.length; e++) {
            let fields = {
                text: text,
                voice_id: voiceId,
                language_id: "1",
                model_id: entry.model,
                format: formats[f]
            };
            let r;
            try {
                r = postForm(BASE + "/api/tts", fields, encodings[e], entry.key);
            } catch (err) {
                return {error: "network"};
            }
            if (r.status === 401 || r.status === 403) return {error: "auth"};
            if (r.status === 429) return {error: "limit"};
            if (r.ok) {
                let j = safeJson(r);
                let d = unwrap(j);
                if (d && d.id) return {id: d.id};
            }
        }
    }
    return {error: "other"};
}

function postForm(url, fields, encoding, key) {
    let headers = {"apikey": key};
    let body;
    if (encoding === "multipart") {
        let boundary = "----vbook" + new Date().getTime();
        body = "";
        for (let k in fields) {
            body += "--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + k + "\"\r\n\r\n" + fields[k] + "\r\n";
        }
        body += "--" + boundary + "--\r\n";
        headers["Content-Type"] = "multipart/form-data; boundary=" + boundary;
    } else {
        let parts = [];
        for (let k in fields) {
            parts.push(encodeURIComponent(k) + "=" + encodeURIComponent(fields[k]));
        }
        body = parts.join("&");
        headers["Content-Type"] = "application/x-www-form-urlencoded";
    }
    return fetch(url, {method: "POST", headers: headers, body: body});
}

function waitResult(id, key) {
    for (let i = 0; i < 90; i++) {
        let r;
        try {
            r = fetch(BASE + "/api/tts/" + id, {headers: {"apikey": key}});
        } catch (err) {
            return null;
        }
        if (r.ok) {
            let d = unwrap(safeJson(r));
            if (d) {
                let st = String(d.status || "").toLowerCase();
                if (st === "failed" || st === "error" || st === "fail") return null;
                if (d.output_path && st !== "pending" && st !== "processing") return d.output_path;
            }
        } else if (r.status === 401 || r.status === 403 || r.status === 404) {
            return null;
        }
        sleep(1000);
    }
    return null;
}

function downloadAudio(path, key) {
    let url = path;
    if (url.indexOf("http") !== 0) {
        url = BASE + (url.charAt(0) === "/" ? "" : "/") + url;
    }
    let r = fetch(url);
    if (!r.ok) r = fetch(url, {headers: {"apikey": key}});
    return r.ok ? r.base64() : null;
}

function safeJson(r) {
    try {
        return r.json();
    } catch (e) {
        return null;
    }
}

function unwrap(j) {
    if (j && j.data && typeof j.data === "object" && !Array.isArray(j.data)) return j.data;
    return j;
}
